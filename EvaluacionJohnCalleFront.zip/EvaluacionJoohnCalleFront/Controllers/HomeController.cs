﻿using EvaluacionJoohnCalleFront.Services;
using Microsoft.AspNetCore.Mvc;

namespace EvaluacionJoohnCalleFront.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApiService _apiService;

        public HomeController(ApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Index()
        {
            // Ejemplo: mostrar títulos de userId=1
            var titulos = await _apiService.ObtenerTitulosPorUserId(1);
            var usuariosExternos = await _apiService.ObtenerUsuariosExternos();

            ViewData["Titulos"] = titulos;
            ViewData["UsuariosExternos"] = usuariosExternos;

            return View();
        }
    }
}
