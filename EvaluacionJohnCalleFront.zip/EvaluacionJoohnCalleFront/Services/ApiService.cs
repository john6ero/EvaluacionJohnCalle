﻿namespace EvaluacionJoohnCalleFront.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;

        public ApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<string>> ObtenerTitulosPorUserId(long userId)
        {
            var url = $"http://localhost:8080/posts/titles/{userId}";
            return await _httpClient.GetFromJsonAsync<List<string>>(url);
        }

        public async Task<List<ExternalUserDto>> ObtenerUsuariosExternos()
        {
            var url = "http://localhost:8080/api/external/users";
            return await _httpClient.GetFromJsonAsync<List<ExternalUserDto>>(url);
        }
    }

    public class ExternalUserDto
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
    }
}
